/*
 * Author: Kira Bertie
 * Created: 12/14/19
 * Description: This program implements the quadratic formula. 
 */
package aaaa;

import java.util.Scanner;

public class MyFirst {

	public static void main(String[] args) {
		
		System.out.println("\t\tWelcome to Quadratic 3000");
		Scanner scnr = new Scanner(System.in);
				
		double root1;
		double root2;
		
		double a;
		double b;
		double c;
		
		double discriminant; 
		
		System.out.println("Input values for a, b, & c: ");
		a = scnr.nextDouble();
		b = scnr.nextDouble();
		c = scnr.nextDouble();
		
		discriminant = (Math.pow(b, 2.0)) - (4 * a * c); 
		root1 = (-b + Math.sqrt(discriminant)) / 2.0 * a;
		root2 = (-b - (Math.sqrt(discriminant))) / 2.0 * a;
		
		System.out.println("Solutions: " + root1 + ", " + root2);
		
		

				


	}

}
